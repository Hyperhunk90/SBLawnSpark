import { html } from 'hono/html'
import { layout } from '../components/layout'
import { localBusinessSchema } from '../utils/schema'

export function portfolioPage() {
  const portfolioSchema = {
    "@context": "https://schema.org",
    "@type": "ImageGallery",
    "name": "Southern Buck Lawn Portfolio",
    "description": "Before and after photos of our professional lawn care and landscaping work",
    "provider": {
      "@type": "LocalBusiness",
      "name": "Southern Buck Lawn",
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "Plano",
        "addressRegion": "TX",
        "postalCode": "75023"
      }
    }
  }

  return layout(
    'Our Work Portfolio - Before & After | Southern Buck Lawn',
    html`
      <script type="application/ld+json">
        ${JSON.stringify(portfolioSchema)}
      </script>
      <script type="application/ld+json">
        ${JSON.stringify(localBusinessSchema)}
      </script>

      <!-- Portfolio Hero Section -->
      <section class="hero-section portfolio-hero" role="banner">
        <div class="hero-content">
          <h1 class="hero-title">Our Work Portfolio</h1>
          <p class="hero-subtitle">See the transformation we bring to North Texas lawns and landscapes</p>
        </div>
        <img 
          src="/static/images/portfolio-hero.jpg" 
          alt="Beautiful transformed landscape showcasing Southern Buck Lawn's expertise" 
          class="hero-bg"
          width="1920" 
          height="1080"
          loading="eager"
          fetchpriority="high"
        >
      </section>

      <!-- Portfolio Gallery -->
      <section class="portfolio-gallery" aria-labelledby="portfolio-heading">
        <div class="container">
          <h2 id="portfolio-heading" class="section-title">Before & After Transformations</h2>
          <p class="section-subtitle">Real results from our satisfied customers across Plano, Frisco, Allen, and McKinney</p>

          <!-- Portfolio Filter Tabs -->
          <div class="portfolio-filters" role="tablist" aria-label="Portfolio categories">
            <button class="filter-btn active" data-filter="all" role="tab" aria-selected="true" aria-controls="portfolio-grid">All Work</button>
            <button class="filter-btn" data-filter="lawn-care" role="tab" aria-selected="false" aria-controls="portfolio-grid">Lawn Care</button>
            <button class="filter-btn" data-filter="landscaping" role="tab" aria-selected="false" aria-controls="portfolio-grid">Landscaping</button>
            <button class="filter-btn" data-filter="tree-work" role="tab" aria-selected="false" aria-controls="portfolio-grid">Tree Work</button>
            <button class="filter-btn" data-filter="cleanup" role="tab" aria-selected="false" aria-controls="portfolio-grid">Cleanup</button>
          </div>

          <!-- Portfolio Grid -->
          <div id="portfolio-grid" class="portfolio-grid" role="tabpanel">

            <!-- Lawn Transformation 1 -->
            <article class="portfolio-item" data-category="lawn-care" itemscope itemtype="https://schema.org/ImageObject">
              <div class="portfolio-image-container">
                <div class="before-after-slider">
                  <div class="before-image">
                    <img 
                      src="/static/images/portfolio/lawn-before-1.jpg" 
                      alt="Overgrown lawn before Southern Buck Lawn service in Plano"
                      width="600"
                      height="400"
                      loading="lazy"
                      itemprop="image"
                    >
                    <span class="image-label">Before</span>
                  </div>
                  <div class="after-image">
                    <img 
                      src="/static/images/portfolio/lawn-after-1.jpg" 
                      alt="Beautiful manicured lawn after professional care"
                      width="600"
                      height="400"
                      loading="lazy"
                    >
                    <span class="image-label">After</span>
                  </div>
                </div>
              </div>
              <div class="portfolio-content">
                <h3 class="portfolio-title" itemprop="name">Plano Lawn Restoration</h3>
                <p class="portfolio-description" itemprop="description">
                  Complete lawn renovation including weed removal, soil conditioning, and precision seeding.
                </p>
                <div class="portfolio-details">
                  <span class="portfolio-location">📍 Plano, TX</span>
                  <span class="portfolio-service">🌱 Lawn Care</span>
                </div>
              </div>
            </article>

            <!-- Tree Trimming Project -->
            <article class="portfolio-item" data-category="tree-work" itemscope itemtype="https://schema.org/ImageObject">
              <div class="portfolio-image-container">
                <div class="before-after-slider">
                  <div class="before-image">
                    <img 
                      src="/static/images/portfolio/tree-before-1.jpg" 
                      alt="Overgrown trees blocking sunlight before trimming"
                      width="600"
                      height="400"
                      loading="lazy"
                      itemprop="image"
                    >
                    <span class="image-label">Before</span>
                  </div>
                  <div class="after-image">
                    <img 
                      src="/static/images/portfolio/tree-after-1.jpg" 
                      alt="Properly pruned trees allowing perfect light balance"
                      width="600"
                      height="400"
                      loading="lazy"
                    >
                    <span class="image-label">After</span>
                  </div>
                </div>
              </div>
              <div class="portfolio-content">
                <h3 class="portfolio-title" itemprop="name">Expert Tree Pruning</h3>
                <p class="portfolio-description" itemprop="description">
                  Professional tree trimming to improve health, safety, and aesthetic appeal.
                </p>
                <div class="portfolio-details">
                  <span class="portfolio-location">📍 Frisco, TX</span>
                  <span class="portfolio-service">🌳 Tree Work</span>
                </div>
              </div>
            </article>

            <!-- Landscape Design -->
            <article class="portfolio-item" data-category="landscaping" itemscope itemtype="https://schema.org/ImageObject">
              <div class="portfolio-image-container">
                <div class="before-after-slider">
                  <div class="before-image">
                    <img 
                      src="/static/images/portfolio/landscape-before-1.jpg" 
                      alt="Plain yard before landscaping transformation"
                      width="600"
                      height="400"
                      loading="lazy"
                      itemprop="image"
                    >
                    <span class="image-label">Before</span>
                  </div>
                  <div class="after-image">
                    <img 
                      src="/static/images/portfolio/landscape-after-1.jpg" 
                      alt="Beautiful landscaped garden with plants and hardscaping"
                      width="600"
                      height="400"
                      loading="lazy"
                    >
                    <span class="image-label">After</span>
                  </div>
                </div>
              </div>
              <div class="portfolio-content">
                <h3 class="portfolio-title" itemprop="name">Complete Landscape Design</h3>
                <p class="portfolio-description" itemprop="description">
                  Full landscape transformation with native plants, irrigation, and hardscape elements.
                </p>
                <div class="portfolio-details">
                  <span class="portfolio-location">📍 Allen, TX</span>
                  <span class="portfolio-service">🌿 Landscaping</span>
                </div>
              </div>
            </article>

            <!-- Yard Cleanup -->
            <article class="portfolio-item" data-category="cleanup" itemscope itemtype="https://schema.org/ImageObject">
              <div class="portfolio-image-container">
                <div class="before-after-slider">
                  <div class="before-image">
                    <img 
                      src="/static/images/portfolio/cleanup-before-1.jpg" 
                      alt="Overgrown yard with debris and fallen leaves"
                      width="600"
                      height="400"
                      loading="lazy"
                      itemprop="image"
                    >
                    <span class="image-label">Before</span>
                  </div>
                  <div class="after-image">
                    <img 
                      src="/static/images/portfolio/cleanup-after-1.jpg" 
                      alt="Clean, organized yard after professional cleanup"
                      width="600"
                      height="400"
                      loading="lazy"
                    >
                    <span class="image-label">After</span>
                  </div>
                </div>
              </div>
              <div class="portfolio-content">
                <h3 class="portfolio-title" itemprop="name">Seasonal Yard Cleanup</h3>
                <p class="portfolio-description" itemprop="description">
                  Comprehensive debris removal, leaf cleanup, and garden bed maintenance.
                </p>
                <div class="portfolio-details">
                  <span class="portfolio-location">📍 McKinney, TX</span>
                  <span class="portfolio-service">🍂 Cleanup</span>
                </div>
              </div>
            </article>

            <!-- Additional Portfolio Items -->
            <article class="portfolio-item" data-category="lawn-care" itemscope itemtype="https://schema.org/ImageObject">
              <div class="portfolio-image-container">
                <div class="before-after-slider">
                  <div class="before-image">
                    <img 
                      src="/static/images/portfolio/lawn-before-2.jpg" 
                      alt="Patchy lawn with brown spots before treatment"
                      width="600"
                      height="400"
                      loading="lazy"
                      itemprop="image"
                    >
                    <span class="image-label">Before</span>
                  </div>
                  <div class="after-image">
                    <img 
                      src="/static/images/portfolio/lawn-after-2.jpg" 
                      alt="Lush green lawn after fertilization and care"
                      width="600"
                      height="400"
                      loading="lazy"
                    >
                    <span class="image-label">After</span>
                  </div>
                </div>
              </div>
              <div class="portfolio-content">
                <h3 class="portfolio-title" itemprop="name">Lawn Health Recovery</h3>
                <p class="portfolio-description" itemprop="description">
                  Soil analysis, fertilization, and targeted treatment for optimal lawn health.
                </p>
                <div class="portfolio-details">
                  <span class="portfolio-location">📍 Plano, TX</span>
                  <span class="portfolio-service">🌱 Lawn Care</span>
                </div>
              </div>
            </article>

            <article class="portfolio-item" data-category="landscaping" itemscope itemtype="https://schema.org/ImageObject">
              <div class="portfolio-image-container">
                <div class="before-after-slider">
                  <div class="before-image">
                    <img 
                      src="/static/images/portfolio/landscape-before-2.jpg" 
                      alt="Empty front yard before landscaping design"
                      width="600"
                      height="400"
                      loading="lazy"
                      itemprop="image"
                    >
                    <span class="image-label">Before</span>
                  </div>
                  <div class="after-image">
                    <img 
                      src="/static/images/portfolio/landscape-after-2.jpg" 
                      alt="Stunning front yard with colorful plants and mulch"
                      width="600"
                      height="400"
                      loading="lazy"
                    >
                    <span class="image-label">After</span>
                  </div>
                </div>
              </div>
              <div class="portfolio-content">
                <h3 class="portfolio-title" itemprop="name">Front Yard Makeover</h3>
                <p class="portfolio-description" itemprop="description">
                  Curb appeal enhancement with seasonal plants, mulching, and design elements.
                </p>
                <div class="portfolio-details">
                  <span class="portfolio-location">📍 Frisco, TX</span>
                  <span class="portfolio-service">🌿 Landscaping</span>
                </div>
              </div>
            </article>

          </div>
        </div>
      </section>

      <!-- Customer Testimonials -->
      <section class="testimonials-section" aria-labelledby="testimonials-heading">
        <div class="container">
          <h2 id="testimonials-heading" class="section-title">What Our Customers Say</h2>

          <div class="testimonials-grid">
            <blockquote class="testimonial-card" itemscope itemtype="https://schema.org/Review">
              <div class="testimonial-content">
                <p class="testimonial-text" itemprop="reviewBody">
                  "Southern Buck transformed our overgrown yard into a beautiful space. Their attention to detail and professionalism exceeded our expectations!"
                </p>
                <div class="testimonial-author">
                  <span class="author-name" itemprop="author">- Sarah M.</span>
                  <span class="author-location">Plano, TX</span>
                </div>
                <div class="testimonial-rating" itemprop="reviewRating" itemscope itemtype="https://schema.org/Rating">
                  <meta itemprop="ratingValue" content="5">
                  <meta itemprop="bestRating" content="5">
                  ⭐⭐⭐⭐⭐
                </div>
              </div>
            </blockquote>

            <blockquote class="testimonial-card" itemscope itemtype="https://schema.org/Review">
              <div class="testimonial-content">
                <p class="testimonial-text" itemprop="reviewBody">
                  "Best lawn care service in North Texas! They're reliable, affordable, and do amazing work. Highly recommend!"
                </p>
                <div class="testimonial-author">
                  <span class="author-name" itemprop="author">- Mike J.</span>
                  <span class="author-location">Frisco, TX</span>
                </div>
                <div class="testimonial-rating" itemprop="reviewRating" itemscope itemtype="https://schema.org/Rating">
                  <meta itemprop="ratingValue" content="5">
                  <meta itemprop="bestRating" content="5">
                  ⭐⭐⭐⭐⭐
                </div>
              </div>
            </blockquote>

            <blockquote class="testimonial-card" itemscope itemtype="https://schema.org/Review">
              <div class="testimonial-content">
                <p class="testimonial-text" itemprop="reviewBody">
                  "The tree trimming work was exceptional. They made our backyard look amazing and removed all the debris. Perfect service!"
                </p>
                <div class="testimonial-author">
                  <span class="author-name" itemprop="author">- Jennifer L.</span>
                  <span class="author-location">Allen, TX</span>
                </div>
                <div class="testimonial-rating" itemprop="reviewRating" itemscope itemtype="https://schema.org/Rating">
                  <meta itemprop="ratingValue" content="5">
                  <meta itemprop="bestRating" content="5">
                  ⭐⭐⭐⭐⭐
                </div>
              </div>
            </blockquote>
          </div>
        </div>
      </section>

      <!-- CTA Section -->
      <section class="cta-section">
        <div class="container">
          <h2 class="cta-title">Ready to Transform Your Landscape?</h2>
          <p class="cta-subtitle">Join our satisfied customers and see the Southern Buck difference for yourself</p>
          <div class="cta-buttons">
            <a href="/contact" class="btn btn-primary">Get Your Free Estimate</a>
            <a href="tel:+1234567890" class="btn btn-secondary">Call (123) 456-7890</a>
          </div>
        </div>
      </section>

      <!-- Portfolio JavaScript for filtering and image interactions -->
      <script>
        // Portfolio filtering functionality
        document.addEventListener('DOMContentLoaded', function() {
          const filterButtons = document.querySelectorAll('.filter-btn');
          const portfolioItems = document.querySelectorAll('.portfolio-item');

          filterButtons.forEach(button => {
            button.addEventListener('click', function() {
              const filter = this.getAttribute('data-filter');

              // Update active button
              filterButtons.forEach(btn => {
                btn.classList.remove('active');
                btn.setAttribute('aria-selected', 'false');
              });
              this.classList.add('active');
              this.setAttribute('aria-selected', 'true');

              // Filter portfolio items
              portfolioItems.forEach(item => {
                if (filter === 'all' || item.getAttribute('data-category') === filter) {
                  item.style.display = 'block';
                  item.setAttribute('aria-hidden', 'false');
                } else {
                  item.style.display = 'none';
                  item.setAttribute('aria-hidden', 'true');
                }
              });
            });
          });
        });
      </script>
    `,
    'View our portfolio of lawn care and landscaping transformations in Plano, Frisco, Allen, and McKinney, TX. Before and after photos of our professional work.'
  )
}