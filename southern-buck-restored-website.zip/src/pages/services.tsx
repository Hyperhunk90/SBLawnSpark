import { html } from 'hono/html'
import { layout } from '../components/layout'
import { localBusinessSchema } from '../utils/schema'

export function servicesPage() {
  const pageSchema = {
    "@context": "https://schema.org",
    "@type": "Service",
    "name": "Professional Lawn Care Services",
    "provider": {
      "@type": "LocalBusiness",
      "name": "Southern Buck Lawn",
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "Plano",
        "addressRegion": "TX",
        "postalCode": "75023"
      }
    },
    "serviceType": "Lawn Care",
    "areaServed": ["Plano", "Frisco", "Allen", "McKinney"],
    "offers": [
      {
        "@type": "Offer",
        "name": "Lawn Mowing",
        "description": "Professional weekly lawn mowing service"
      },
      {
        "@type": "Offer", 
        "name": "Tree Trimming",
        "description": "Expert tree pruning and trimming"
      },
      {
        "@type": "Offer",
        "name": "Landscaping",
        "description": "Complete landscape design and maintenance"
      }
    ]
  }

  return layout(
    'Our Services - Professional Lawn Care | Southern Buck Lawn',
    html`
      <script type="application/ld+json">
        ${JSON.stringify(pageSchema)}
      </script>
      <script type="application/ld+json">
        ${JSON.stringify(localBusinessSchema)}
      </script>

      <!-- Services Hero Section -->
      <section class="hero-section services-hero" role="banner">
        <div class="hero-content">
          <h1 class="hero-title">Professional Lawn Care Services</h1>
          <p class="hero-subtitle">Comprehensive lawn and landscape solutions for North Texas</p>
        </div>
        <img 
          src="/static/images/services-hero.jpg" 
          alt="Professional lawn care equipment and landscaping tools" 
          class="hero-bg"
          width="1920" 
          height="1080"
          loading="eager"
          fetchpriority="high"
        >
      </section>

      <!-- Services Grid -->
      <section class="services-grid" aria-labelledby="services-heading">
        <div class="container">
          <h2 id="services-heading" class="section-title">Our Services</h2>

          <div class="services-container">
            <!-- Lawn Mowing Service -->
            <article class="service-card" itemscope itemtype="https://schema.org/Service">
              <div class="service-image-container">
                <img 
                  src="/static/images/lawn-mowing.jpg" 
                  alt="Professional lawn mowing service in Plano TX"
                  class="service-image"
                  width="400"
                  height="300"
                  loading="lazy"
                  itemprop="image"
                >
              </div>
              <div class="service-content">
                <h3 class="service-title" itemprop="name">Lawn Mowing</h3>
                <p class="service-description" itemprop="description">
                  Professional weekly lawn mowing with precision cutting and edge trimming. 
                  We maintain your lawn's health while keeping it looking pristine.
                </p>
                <ul class="service-features">
                  <li>Weekly scheduled service</li>
                  <li>Precision cutting heights</li>
                  <li>Edge trimming included</li>
                  <li>Debris cleanup</li>
                </ul>
                <meta itemprop="serviceType" content="Lawn Mowing">
              </div>
            </article>

            <!-- Tree Trimming Service -->
            <article class="service-card" itemscope itemtype="https://schema.org/Service">
              <div class="service-image-container">
                <img 
                  src="/static/images/tree-trimming.jpg" 
                  alt="Expert tree trimming and pruning services"
                  class="service-image"
                  width="400"
                  height="300"
                  loading="lazy"
                  itemprop="image"
                >
              </div>
              <div class="service-content">
                <h3 class="service-title" itemprop="name">Tree Trimming</h3>
                <p class="service-description" itemprop="description">
                  Expert tree pruning and trimming to maintain tree health, safety, and aesthetics. 
                  Our certified arborists ensure proper techniques for long-term tree vitality.
                </p>
                <ul class="service-features">
                  <li>Certified arborist techniques</li>
                  <li>Safety-focused approach</li>
                  <li>Health assessment included</li>
                  <li>Complete cleanup service</li>
                </ul>
                <meta itemprop="serviceType" content="Tree Trimming">
              </div>
            </article>

            <!-- Landscaping Service -->
            <article class="service-card" itemscope itemtype="https://schema.org/Service">
              <div class="service-image-container">
                <img 
                  src="/static/images/landscaping.jpg" 
                  alt="Professional landscaping and garden design"
                  class="service-image"
                  width="400"
                  height="300"
                  loading="lazy"
                  itemprop="image"
                >
              </div>
              <div class="service-content">
                <h3 class="service-title" itemprop="name">Landscaping</h3>
                <p class="service-description" itemprop="description">
                  Complete landscape design, installation, and maintenance services. 
                  Transform your outdoor space with professional planning and expert execution.
                </p>
                <ul class="service-features">
                  <li>Custom design consultation</li>
                  <li>Plant selection & installation</li>
                  <li>Hardscape integration</li>
                  <li>Ongoing maintenance</li>
                </ul>
                <meta itemprop="serviceType" content="Landscaping">
              </div>
            </article>

            <!-- Leaf Removal Service -->
            <article class="service-card" itemscope itemtype="https://schema.org/Service">
              <div class="service-image-container">
                <img 
                  src="/static/images/leaf-removal.jpg" 
                  alt="Seasonal leaf removal and yard cleanup"
                  class="service-image"
                  width="400"
                  height="300"
                  loading="lazy"
                  itemprop="image"
                >
              </div>
              <div class="service-content">
                <h3 class="service-title" itemprop="name">Leaf Removal</h3>
                <p class="service-description" itemprop="description">
                  Comprehensive seasonal leaf removal and yard cleanup services. 
                  Keep your lawn healthy and your property looking great year-round.
                </p>
                <ul class="service-features">
                  <li>Complete leaf removal</li>
                  <li>Gutter cleaning available</li>
                  <li>Seasonal scheduling</li>
                  <li>Eco-friendly disposal</li>
                </ul>
                <meta itemprop="serviceType" content="Leaf Removal">
              </div>
            </article>

            <!-- Mulching Service -->
            <article class="service-card" itemscope itemtype="https://schema.org/Service">
              <div class="service-image-container">
                <img 
                  src="/static/images/mulching.jpg" 
                  alt="Professional mulching and bed maintenance"
                  class="service-image"
                  width="400"
                  height="300"
                  loading="lazy"
                  itemprop="image"
                >
              </div>
              <div class="service-content">
                <h3 class="service-title" itemprop="name">Mulching</h3>
                <p class="service-description" itemprop="description">
                  Professional mulching services to improve soil health, retain moisture, 
                  and enhance the appearance of your garden beds and landscaping.
                </p>
                <ul class="service-features">
                  <li>Premium mulch materials</li>
                  <li>Proper depth application</li>
                  <li>Weed suppression</li>
                  <li>Moisture retention</li>
                </ul>
                <meta itemprop="serviceType" content="Mulching">
              </div>
            </article>

            <!-- Pressure Washing Service -->
            <article class="service-card" itemscope itemtype="https://schema.org/Service">
              <div class="service-image-container">
                <img 
                  src="/static/images/pressure-washing.jpg" 
                  alt="Professional pressure washing services"
                  class="service-image"
                  width="400"
                  height="300"
                  loading="lazy"
                  itemprop="image"
                >
              </div>
              <div class="service-content">
                <h3 class="service-title" itemprop="name">Pressure Washing</h3>
                <p class="service-description" itemprop="description">
                  Professional pressure washing for driveways, sidewalks, patios, and home exteriors. 
                  Restore the beauty of your outdoor surfaces with our expert cleaning services.
                </p>
                <ul class="service-features">
                  <li>Driveway & sidewalk cleaning</li>
                  <li>Patio & deck restoration</li>
                  <li>House exterior washing</li>
                  <li>Eco-friendly solutions</li>
                </ul>
                <meta itemprop="serviceType" content="Pressure Washing">
              </div>
            </article>
          </div>
        </div>
      </section>

      <!-- Service Areas -->
      <section class="service-areas" aria-labelledby="areas-heading">
        <div class="container">
          <h2 id="areas-heading" class="section-title">Service Areas</h2>
          <p class="section-subtitle">Proudly serving North Texas communities</p>

          <div class="areas-grid">
            <div class="area-card">
              <h3>Plano, TX</h3>
              <p>Comprehensive lawn care services throughout Plano and surrounding neighborhoods.</p>
            </div>
            <div class="area-card">
              <h3>Frisco, TX</h3>
              <p>Professional landscaping and maintenance for Frisco residents and businesses.</p>
            </div>
            <div class="area-card">
              <h3>Allen, TX</h3>
              <p>Expert tree trimming and lawn mowing services for the Allen community.</p>
            </div>
            <div class="area-card">
              <h3>McKinney, TX</h3>
              <p>Complete outdoor maintenance solutions for McKinney properties.</p>
            </div>
          </div>
        </div>
      </section>

      <!-- CTA Section -->
      <section class="cta-section">
        <div class="container">
          <h2 class="cta-title">Ready to Transform Your Outdoor Space?</h2>
          <p class="cta-subtitle">Get your free estimate today and discover the Southern Buck difference</p>
          <div class="cta-buttons">
            <a href="/contact" class="btn btn-primary">Get Free Estimate</a>
            <a href="tel:+1234567890" class="btn btn-secondary">Call Now</a>
          </div>
        </div>
      </section>
    `,
    'Professional lawn care services including mowing, tree trimming, landscaping, and more. Serving Plano, Frisco, Allen, and McKinney, TX.'
  )
}