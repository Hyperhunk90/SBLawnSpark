import { Context } from 'hono'
import { Layout } from '../components/layout'
import { getLocalBusinessSchema } from '../utils/schema'

export const homePage = (c: Context) => {
  const schema = getLocalBusinessSchema()

  const content = `
    <!-- Hero Section with Video Background -->
    <section class="relative min-h-screen flex items-center justify-center overflow-hidden">
      <!-- Hero Video Background -->
      <video 
        autoplay 
        muted 
        loop 
        playsinline 
        class="hero-video"
        poster="/static/images/hero-bg.jpg"
        loading="eager"
        preload="metadata"
      >
        <source src="/static/videos/lawn-care-hero.mp4" type="video/mp4">
        <!-- Fallback for browsers that don't support video -->
        Your browser does not support the video tag.
      </video>

      <!-- Fallback Image (hidden by default, shown if video fails) -->
      <img 
        src="/static/images/hero-bg.jpg" 
        alt="Professional Lawn Care Service" 
        class="hero-video" 
        style="display: none;"
        loading="eager"
      >

      <div class="hero-overlay"></div>

      <div class="relative z-10 text-center px-4 fade-in">
        <img 
          src="/static/images/logo-large.png" 
          alt="Southern Buck Lawn - Professional Lawn Care" 
          class="h-48 md:h-64 mx-auto mb-8 animate-pulse"
          loading="eager"
          fetchpriority="high"
        >

        <h1 class="text-5xl md:text-7xl font-bebas text-white mb-6 text-glow">
          Professional Lawn Care & Landscaping
        </h1>

        <p class="text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto leading-relaxed">
          Licensed & Insured | Free Estimates | Walker, LA & Surrounding Areas
        </p>

        <div class="flex flex-col sm:flex-row gap-6 justify-center items-center">
          <a href="https://forms.gle/Mut7H9YsjZDf6jUn6" 
             target="_blank" 
             class="bg-lime-green text-dark-gray px-10 py-4 rounded-full text-xl font-bold btn-hover transform hover:scale-105 transition-all duration-300 shadow-2xl">
            <i class="fas fa-clipboard-list mr-3"></i>Get Free Quote
          </a>
          <a href="tel:225-369-4434" 
             class="bg-transparent border-2 border-lime-green text-lime-green px-10 py-4 rounded-full text-xl font-bold btn-hover transform hover:scale-105 transition-all duration-300 hover:bg-lime-green hover:text-dark-gray shadow-2xl">
            <i class="fas fa-phone mr-3"></i>Call 225-369-4434
          </a>
        </div>

        <!-- Scroll Indicator -->
        <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <i class="fas fa-chevron-down text-3xl text-lime-green"></i>
        </div>
      </div>
    </section>

    <!-- Meet Shane Section -->
    <section class="py-20 bg-gradient-to-b from-medium-gray to-dark-gray">
      <div class="container mx-auto px-4">
        <h2 class="text-5xl md:text-6xl font-bebas text-center mb-16 scroll-animate">
          Meet <span class="gradient-text">Shane Dantone</span>
        </h2>

        <div class="grid lg:grid-cols-2 gap-16 items-center max-w-7xl mx-auto">
          <div class="scroll-animate">
            <img 
              src="/static/images/team-shane.jpg" 
              alt="Shane Dantone - Owner of Southern Buck Lawn" 
              class="rounded-2xl shadow-2xl mx-auto lg:mx-0 max-w-sm transform hover:scale-105 transition-transform duration-500"
              loading="lazy"
            >
          </div>

          <div class="scroll-animate">
            <h3 class="text-4xl font-bebas text-lime-green mb-6">Owner & Operator</h3>
            <div class="space-y-6 text-lg text-gray-300 leading-relaxed">
              <p>
                Shane Dantone is a 35-year-old former industrial electrician with 13+ years of hands-on experience. After years in the electrical field, Shane followed his passion for lawn care and landscaping, investing everything into Southern Buck Lawn.
              </p>
              <blockquote class="border-l-4 border-lime-green pl-6 italic text-xl text-white">
                "I treat every client's yard like it's my own."
              </blockquote>
              <p>
                This personal approach, combined with all-new professional equipment, sets Southern Buck Lawn apart from the competition. Based right here in Walker, LA on Brett Dr., Shane personally oversees every project to ensure the highest quality results for your property.
              </p>
            </div>
            <div class="mt-8">
              <a href="tel:225-369-4434" 
                 class="bg-lime-green text-dark-gray px-8 py-4 rounded-full font-bold btn-hover inline-block transform hover:scale-105 transition-all duration-300">
                <i class="fas fa-phone mr-2"></i>Call Shane Today
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Services Section -->
    <section class="py-20 bg-dark-gray">
      <div class="container mx-auto px-4">
        <h2 class="text-5xl md:text-6xl font-bebas text-center mb-8 scroll-animate">
          <span class="gradient-text">Our Services</span>
        </h2>
        <p class="text-xl text-center text-gray-400 mb-16 scroll-animate max-w-3xl mx-auto">
          Comprehensive Lawn Care & Landscaping Solutions for Walker, LA and Surrounding Areas
        </p>

        <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          ${getServicesHTML()}
        </div>

        <div class="text-center mt-16">
          <a href="/services" 
             class="bg-lime-green text-dark-gray px-10 py-4 rounded-full text-lg font-bold btn-hover inline-block transform hover:scale-105 transition-all duration-300">
            View All Services <i class="fas fa-arrow-right ml-2"></i>
          </a>
        </div>
      </div>
    </section>

    <!-- Why Choose Us Section -->
    <section class="py-20 bg-gradient-to-b from-medium-gray to-dark-gray">
      <div class="container mx-auto px-4">
        <h2 class="text-5xl md:text-6xl font-bebas text-center mb-16 scroll-animate">
          Why Choose <span class="gradient-text">Southern Buck Lawn</span>?
        </h2>

        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
          <div class="bg-dark-gray/50 p-8 rounded-2xl scroll-animate card-hover backdrop-blur-sm border border-lime-green/10">
            <div class="text-center">
              <i class="fas fa-user-tie text-5xl text-lime-green mb-6"></i>
              <h3 class="text-2xl font-bebas mb-4 text-lime-green">Owner-Operated</h3>
              <p class="text-gray-400 leading-relaxed">Shane Dantone personally oversees every project, bringing 13+ years of professional experience and treating your lawn as his own.</p>
            </div>
          </div>

          <div class="bg-dark-gray/50 p-8 rounded-2xl scroll-animate card-hover backdrop-blur-sm border border-lime-green/10">
            <div class="text-center">
              <i class="fas fa-tools text-5xl text-lime-green mb-6"></i>
              <h3 class="text-2xl font-bebas mb-4 text-lime-green">All New Equipment</h3>
              <p class="text-gray-400 leading-relaxed">We've invested in brand new, professional-grade equipment to deliver the highest quality results for your property.</p>
            </div>
          </div>

          <div class="bg-dark-gray/50 p-8 rounded-2xl scroll-animate card-hover backdrop-blur-sm border border-lime-green/10">
            <div class="text-center">
              <i class="fas fa-shield-alt text-5xl text-lime-green mb-6"></i>
              <h3 class="text-2xl font-bebas mb-4 text-lime-green">Licensed & Insured</h3>
              <p class="text-gray-400 leading-relaxed">Fully licensed and insured for your peace of mind. We stand behind our work with complete professionalism.</p>
            </div>
          </div>

          <div class="bg-dark-gray/50 p-8 rounded-2xl scroll-animate card-hover backdrop-blur-sm border border-lime-green/10">
            <div class="text-center">
              <i class="fas fa-heart text-5xl text-lime-green mb-6"></i>
              <h3 class="text-2xl font-bebas mb-4 text-lime-green">Passion-Driven</h3>
              <p class="text-gray-400 leading-relaxed">This isn't just a business—it's our passion. We take pride in every cut, every trim, and every landscape we create.</p>
            </div>
          </div>

          <div class="bg-dark-gray/50 p-8 rounded-2xl scroll-animate card-hover backdrop-blur-sm border border-lime-green/10">
            <div class="text-center">
              <i class="fas fa-map-marked-alt text-5xl text-lime-green mb-6"></i>
              <h3 class="text-2xl font-bebas mb-4 text-lime-green">Local Expertise</h3>
              <p class="text-gray-400 leading-relaxed">Based in Walker, LA, we understand the unique lawn care needs of our Louisiana climate and soil conditions.</p>
            </div>
          </div>

          <div class="bg-dark-gray/50 p-8 rounded-2xl scroll-animate card-hover backdrop-blur-sm border border-lime-green/10">
            <div class="text-center">
              <i class="fas fa-dollar-sign text-5xl text-lime-green mb-6"></i>
              <h3 class="text-2xl font-bebas mb-4 text-lime-green">Free Estimates</h3>
              <p class="text-gray-400 leading-relaxed">Get a detailed, no-obligation quote for your project. We believe in transparent, fair pricing for all our services.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Testimonials Section -->
    <section class="py-20 bg-dark-gray">
      <div class="container mx-auto px-4">
        <h2 class="text-5xl md:text-6xl font-bebas text-center mb-16 scroll-animate">
          What Our <span class="gradient-text">Customers Say</span>
        </h2>

        <div class="grid md:grid-cols-3 gap-10">
          <div class="bg-medium-gray p-8 rounded-2xl scroll-animate card-hover">
            <div class="flex mb-6 justify-center">
              <i class="fas fa-star text-lime-green text-xl"></i>
              <i class="fas fa-star text-lime-green text-xl"></i>
              <i class="fas fa-star text-lime-green text-xl"></i>
              <i class="fas fa-star text-lime-green text-xl"></i>
              <i class="fas fa-star text-lime-green text-xl"></i>
            </div>
            <p class="text-gray-300 mb-6 text-center leading-relaxed italic">"Shane and his team transformed our yard! Professional, punctual, and the attention to detail is outstanding. Highly recommend Southern Buck Lawn!"</p>
            <p class="text-lime-green font-bold text-center">- Sarah M., Walker</p>
          </div>

          <div class="bg-medium-gray p-8 rounded-2xl scroll-animate card-hover">
            <div class="flex mb-6 justify-center">
              <i class="fas fa-star text-lime-green text-xl"></i>
              <i class="fas fa-star text-lime-green text-xl"></i>
              <i class="fas fa-star text-lime-green text-xl"></i>
              <i class="fas fa-star text-lime-green text-xl"></i>
              <i class="fas fa-star text-lime-green text-xl"></i>
            </div>
            <p class="text-gray-300 mb-6 text-center leading-relaxed italic">"Best lawn service in the area! They installed our new landscape design and it looks amazing. Fair pricing and excellent work."</p>
            <p class="text-lime-green font-bold text-center">- Mike T., Denham Springs</p>
          </div>

          <div class="bg-medium-gray p-8 rounded-2xl scroll-animate card-hover">
            <div class="flex mb-6 justify-center">
              <i class="fas fa-star text-lime-green text-xl"></i>
              <i class="fas fa-star text-lime-green text-xl"></i>
              <i class="fas fa-star text-lime-green text-xl"></i>
              <i class="fas fa-star text-lime-green text-xl"></i>
              <i class="fas fa-star text-lime-green text-xl"></i>
            </div>
            <p class="text-gray-300 mb-6 text-center leading-relaxed italic">"Reliable weekly mowing service. Shane treats our lawn like it's his own. You can tell he takes pride in his work!"</p>
            <p class="text-lime-green font-bold text-center">- Jennifer R., Port Vincent</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Portfolio Section -->
    <section class="py-20 bg-gradient-to-b from-medium-gray to-dark-gray">
      <div class="container mx-auto px-4">
        <h2 class="text-5xl md:text-6xl font-bebas text-center mb-16 scroll-animate">
          Our <span class="gradient-text">Recent Work</span>
        </h2>

        <div class="grid md:grid-cols-3 gap-8">
          <div class="relative group overflow-hidden rounded-2xl scroll-animate">
            <img 
              src="/static/images/portfolio/lawn-2.jpg" 
              alt="Lawn Transformation Before and After" 
              class="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-500"
              loading="lazy"
            >
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-6">
              <div>
                <p class="text-white font-bold text-xl mb-2">Complete Lawn Transformation</p>
                <p class="text-gray-300 text-sm">Before & After Results</p>
              </div>
            </div>
          </div>

          <div class="relative group overflow-hidden rounded-2xl scroll-animate">
            <img 
              src="/static/images/portfolio/landscape-2.jpg" 
              alt="Landscaping Transformation 2017-2019" 
              class="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-500"
              loading="lazy"
            >
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-6">
              <div>
                <p class="text-white font-bold text-xl mb-2">Garden Design & Installation</p>
                <p class="text-gray-300 text-sm">Custom Landscape Projects</p>
              </div>
            </div>
          </div>

          <div class="relative group overflow-hidden rounded-2xl scroll-animate">
            <img 
              src="/static/images/portfolio/hardscape-2.jpg" 
              alt="Backyard Patio Transformation" 
              class="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-500"
              loading="lazy"
            >
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-6">
              <div>
                <p class="text-white font-bold text-xl mb-2">Complete Backyard Makeover</p>
                <p class="text-gray-300 text-sm">Hardscape & Outdoor Living</p>
              </div>
            </div>
          </div>
        </div>

        <div class="text-center mt-16">
          <a href="/portfolio" 
             class="bg-lime-green text-dark-gray px-10 py-4 rounded-full text-lg font-bold btn-hover inline-block transform hover:scale-105 transition-all duration-300">
            View Full Portfolio <i class="fas fa-arrow-right ml-2"></i>
          </a>
        </div>
      </div>
    </section>

    <!-- CTA Section -->
    <section class="py-20 bg-lime-green relative overflow-hidden">
      <div class="absolute inset-0 bg-gradient-to-r from-lime-green to-green-400"></div>
      <div class="container mx-auto px-4 text-center relative z-10">
        <h2 class="text-5xl md:text-6xl font-bebas text-dark-gray mb-8">
          Ready to Transform Your Lawn?
        </h2>
        <p class="text-xl text-dark-gray/80 mb-10 max-w-3xl mx-auto leading-relaxed">
          Get your free estimate today! Call now or request a quote online. Join the growing number of satisfied customers in Walker, LA and surrounding areas.
        </p>

        <div class="flex flex-col sm:flex-row gap-6 justify-center items-center">
          <a href="tel:225-369-4434" 
             class="bg-dark-gray text-lime-green px-10 py-4 rounded-full text-xl font-bold btn-hover transform hover:scale-105 transition-all duration-300 shadow-2xl">
            <i class="fas fa-phone mr-3"></i>Call 225-369-4434
          </a>
          <a href="https://forms.gle/Mut7H9YsjZDf6jUn6" 
             target="_blank"
             class="bg-white text-dark-gray px-10 py-4 rounded-full text-xl font-bold btn-hover transform hover:scale-105 transition-all duration-300 shadow-2xl">
            <i class="fas fa-envelope mr-3"></i>Request Online Quote
          </a>
        </div>
      </div>
    </section>
  `

  return c.html(Layout({
    title: 'Southern Buck Lawn | Professional Lawn Care & Landscaping in Walker, LA',
    description: 'Southern Buck Lawn offers professional lawn care and landscaping services in Walker, LA and surrounding areas. Licensed, insured, and owner-operated. Call 225-369-4434 for a free estimate.',
    children: content,
    canonicalUrl: 'https://southernbucklawn.com',
    schema
  }))
}

function getServicesHTML() {
  const services = [
    { icon: 'fa-grass', name: 'Weekly/Bi-Weekly Mowing', desc: 'Professional lawn cutting services', color: 'text-lime-green' },
    { icon: 'fa-tree', name: 'Shrub Trimming', desc: 'Expert pruning and shaping', color: 'text-green-400' },
    { icon: 'fa-seedling', name: 'Mulching', desc: 'Fresh mulch installation', color: 'text-lime-green' },
    { icon: 'fa-leaf', name: 'Weed Removal', desc: 'Complete weed control', color: 'text-green-400' },
    { icon: 'fa-home', name: 'Gutter Cleaning', desc: 'Clear and maintain gutters', color: 'text-lime-green' },
    { icon: 'fa-tools', name: 'Lawn Maintenance', desc: 'Complete lawn care packages', color: 'text-green-400' },
    { icon: 'fa-drafting-compass', name: 'Landscape Design', desc: '3D planning and design', color: 'text-lime-green' },
    { icon: 'fa-chess-board', name: 'Hardscapes/Pavers', desc: 'Patios and walkways', color: 'text-green-400' }
  ]

  return services.map((service, index) => `
    <div class="bg-medium-gray/50 p-8 rounded-2xl card-hover scroll-animate backdrop-blur-sm border border-lime-green/10 text-center">
      <i class="fas ${service.icon} text-4xl ${service.color} mb-6 transform group-hover:scale-110 transition-transform duration-300"></i>
      <h3 class="text-xl font-bebas mb-3 text-white">${service.name}</h3>
      <p class="text-gray-400 text-sm leading-relaxed">${service.desc}</p>
    </div>
  `).join('')
}