import { html } from 'hono/html'
import { layout } from '../components/layout'
import { localBusinessSchema } from '../utils/schema'

export function contactPage() {
  const contactSchema = {
    "@context": "https://schema.org",
    "@type": "ContactPage",
    "name": "Contact Southern Buck Lawn",
    "description": "Get a free estimate for professional lawn care services in Plano, Frisco, Allen, and McKinney, TX",
    "mainEntity": {
      "@type": "LocalBusiness",
      "name": "Southern Buck Lawn",
      "telephone": "+1234567890",
      "email": "info@southernbucklawn.com",
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "Plano",
        "addressRegion": "TX",
        "postalCode": "75023",
        "addressCountry": "US"
      },
      "openingHours": [
        "Mo-Fr 07:00-18:00",
        "Sa 08:00-16:00"
      ]
    }
  }

  return layout(
    'Contact Us - Free Estimate | Southern Buck Lawn',
    html`
      <script type="application/ld+json">
        ${JSON.stringify(contactSchema)}
      </script>
      <script type="application/ld+json">
        ${JSON.stringify(localBusinessSchema)}
      </script>

      <!-- Contact Hero Section -->
      <section class="hero-section contact-hero" role="banner">
        <div class="hero-content">
          <h1 class="hero-title">Get Your Free Estimate</h1>
          <p class="hero-subtitle">Professional lawn care services with transparent pricing and reliable service</p>
        </div>
        <img 
          src="/static/images/contact-hero.jpg" 
          alt="Professional lawn care consultation and free estimate" 
          class="hero-bg"
          width="1920" 
          height="1080"
          loading="eager"
          fetchpriority="high"
        >
      </section>

      <!-- Contact Form & Info Section -->
      <section class="contact-section">
        <div class="container">
          <div class="contact-grid">

            <!-- Contact Form -->
            <div class="contact-form-container">
              <h2 class="form-title">Request Your Free Estimate</h2>
              <p class="form-subtitle">Fill out the form below and we'll get back to you within 24 hours</p>

              <form class="contact-form" id="estimateForm" action="/submit-estimate" method="POST" novalidate>
                <!-- Form Fields -->
                <div class="form-group">
                  <label for="firstName" class="form-label">First Name *</label>
                  <input 
                    type="text" 
                    id="firstName" 
                    name="firstName" 
                    class="form-input" 
                    required 
                    aria-describedby="firstName-error"
                    autocomplete="given-name"
                  >
                  <span class="error-message" id="firstName-error" role="alert" aria-live="polite"></span>
                </div>

                <div class="form-group">
                  <label for="lastName" class="form-label">Last Name *</label>
                  <input 
                    type="text" 
                    id="lastName" 
                    name="lastName" 
                    class="form-input" 
                    required 
                    aria-describedby="lastName-error"
                    autocomplete="family-name"
                  >
                  <span class="error-message" id="lastName-error" role="alert" aria-live="polite"></span>
                </div>

                <div class="form-group">
                  <label for="email" class="form-label">Email Address *</label>
                  <input 
                    type="email" 
                    id="email" 
                    name="email" 
                    class="form-input" 
                    required 
                    aria-describedby="email-error"
                    autocomplete="email"
                  >
                  <span class="error-message" id="email-error" role="alert" aria-live="polite"></span>
                </div>

                <div class="form-group">
                  <label for="phone" class="form-label">Phone Number *</label>
                  <input 
                    type="tel" 
                    id="phone" 
                    name="phone" 
                    class="form-input" 
                    required 
                    aria-describedby="phone-error"
                    autocomplete="tel"
                    placeholder="(123) 456-7890"
                  >
                  <span class="error-message" id="phone-error" role="alert" aria-live="polite"></span>
                </div>

                <div class="form-group">
                  <label for="address" class="form-label">Property Address *</label>
                  <input 
                    type="text" 
                    id="address" 
                    name="address" 
                    class="form-input" 
                    required 
                    aria-describedby="address-error"
                    autocomplete="street-address"
                    placeholder="123 Main St, Plano, TX 75023"
                  >
                  <span class="error-message" id="address-error" role="alert" aria-live="polite"></span>
                </div>

                <div class="form-group">
                  <label for="city" class="form-label">City *</label>
                  <select 
                    id="city" 
                    name="city" 
                    class="form-select" 
                    required 
                    aria-describedby="city-error"
                  >
                    <option value="">Select your city</option>
                    <option value="plano">Plano</option>
                    <option value="frisco">Frisco</option>
                    <option value="allen">Allen</option>
                    <option value="mckinney">McKinney</option>
                    <option value="other">Other (please specify in comments)</option>
                  </select>
                  <span class="error-message" id="city-error" role="alert" aria-live="polite"></span>
                </div>

                <div class="form-group">
                  <label for="services" class="form-label">Services Needed *</label>
                  <div class="checkbox-group" role="group" aria-labelledby="services">
                    <label class="checkbox-label">
                      <input type="checkbox" name="services[]" value="lawn-mowing" class="checkbox-input">
                      <span class="checkbox-text">Lawn Mowing</span>
                    </label>
                    <label class="checkbox-label">
                      <input type="checkbox" name="services[]" value="tree-trimming" class="checkbox-input">
                      <span class="checkbox-text">Tree Trimming</span>
                    </label>
                    <label class="checkbox-label">
                      <input type="checkbox" name="services[]" value="landscaping" class="checkbox-input">
                      <span class="checkbox-text">Landscaping</span>
                    </label>
                    <label class="checkbox-label">
                      <input type="checkbox" name="services[]" value="leaf-removal" class="checkbox-input">
                      <span class="checkbox-text">Leaf Removal</span>
                    </label>
                    <label class="checkbox-label">
                      <input type="checkbox" name="services[]" value="mulching" class="checkbox-input">
                      <span class="checkbox-text">Mulching</span>
                    </label>
                    <label class="checkbox-label">
                      <input type="checkbox" name="services[]" value="pressure-washing" class="checkbox-input">
                      <span class="checkbox-text">Pressure Washing</span>
                    </label>
                  </div>
                  <span class="error-message" id="services-error" role="alert" aria-live="polite"></span>
                </div>

                <div class="form-group">
                  <label for="propertySize" class="form-label">Approximate Property Size</label>
                  <select id="propertySize" name="propertySize" class="form-select">
                    <option value="">Select property size</option>
                    <option value="small">Small (under 0.25 acres)</option>
                    <option value="medium">Medium (0.25 - 0.5 acres)</option>
                    <option value="large">Large (0.5 - 1 acre)</option>
                    <option value="extra-large">Extra Large (1+ acres)</option>
                  </select>
                </div>

                <div class="form-group">
                  <label for="frequency" class="form-label">Service Frequency</label>
                  <select id="frequency" name="frequency" class="form-select">
                    <option value="">Select frequency</option>
                    <option value="weekly">Weekly</option>
                    <option value="bi-weekly">Bi-weekly</option>
                    <option value="monthly">Monthly</option>
                    <option value="seasonal">Seasonal</option>
                    <option value="one-time">One-time service</option>
                  </select>
                </div>

                <div class="form-group">
                  <label for="comments" class="form-label">Additional Comments</label>
                  <textarea 
                    id="comments" 
                    name="comments" 
                    class="form-textarea" 
                    rows="4"
                    placeholder="Tell us about any specific needs, concerns, or questions..."
                  ></textarea>
                </div>

                <div class="form-group">
                  <label for="preferredContact" class="form-label">Preferred Contact Method</label>
                  <div class="radio-group" role="radiogroup" aria-labelledby="preferredContact">
                    <label class="radio-label">
                      <input type="radio" name="preferredContact" value="phone" class="radio-input" checked>
                      <span class="radio-text">Phone Call</span>
                    </label>
                    <label class="radio-label">
                      <input type="radio" name="preferredContact" value="email" class="radio-input">
                      <span class="radio-text">Email</span>
                    </label>
                    <label class="radio-label">
                      <input type="radio" name="preferredContact" value="text" class="radio-input">
                      <span class="radio-text">Text Message</span>
                    </label>
                  </div>
                </div>

                <div class="form-group">
                  <label for="bestTime" class="form-label">Best Time to Contact</label>
                  <select id="bestTime" name="bestTime" class="form-select">
                    <option value="">Any time</option>
                    <option value="morning">Morning (8AM - 12PM)</option>
                    <option value="afternoon">Afternoon (12PM - 5PM)</option>
                    <option value="evening">Evening (5PM - 8PM)</option>
                  </select>
                </div>

                <!-- Form Submission -->
                <div class="form-submit">
                  <button type="submit" class="btn btn-primary form-submit-btn" id="submitBtn">
                    <span class="btn-text">Get My Free Estimate</span>
                    <span class="btn-loading" style="display: none;">Sending...</span>
                  </button>
                  <p class="form-disclaimer">
                    By submitting this form, you agree to receive communications from Southern Buck Lawn. 
                    We respect your privacy and will never share your information.
                  </p>
                </div>
              </form>
            </div>

            <!-- Contact Information -->
            <div class="contact-info-container">
              <div class="contact-info-card" itemscope itemtype="https://schema.org/LocalBusiness">
                <h3 class="contact-info-title" itemprop="name">Southern Buck Lawn</h3>

                <div class="contact-info-item">
                  <div class="contact-icon">📞</div>
                  <div class="contact-details">
                    <h4>Phone</h4>
                    <a href="tel:+1234567890" class="contact-link" itemprop="telephone">(123) 456-7890</a>
                    <p class="contact-note">Call or text for immediate assistance</p>
                  </div>
                </div>

                <div class="contact-info-item">
                  <div class="contact-icon">✉️</div>
                  <div class="contact-details">
                    <h4>Email</h4>
                    <a href="mailto:info@southernbucklawn.com" class="contact-link" itemprop="email">info@southernbucklawn.com</a>
                    <p class="contact-note">We respond within 24 hours</p>
                  </div>
                </div>

                <div class="contact-info-item" itemprop="address" itemscope itemtype="https://schema.org/PostalAddress">
                  <div class="contact-icon">📍</div>
                  <div class="contact-details">
                    <h4>Service Area</h4>
                    <p>
                      <span itemprop="addressLocality">Plano</span>, 
                      <span itemprop="addressRegion">TX</span> & Surrounding Areas
                    </p>
                    <p class="contact-note">Frisco, Allen, McKinney & more</p>
                  </div>
                </div>

                <div class="contact-info-item">
                  <div class="contact-icon">🕒</div>
                  <div class="contact-details">
                    <h4>Business Hours</h4>
                    <div class="hours-list" itemprop="openingHours" content="Mo-Fr 07:00-18:00">
                      <p>Monday - Friday: 7:00 AM - 6:00 PM</p>
                      <p itemprop="openingHours" content="Sa 08:00-16:00">Saturday: 8:00 AM - 4:00 PM</p>
                      <p>Sunday: Closed</p>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Emergency Contact -->
              <div class="emergency-contact">
                <h4>Emergency Tree Service</h4>
                <p>Storm damage? Fallen tree? We offer 24/7 emergency tree removal services.</p>
                <a href="tel:+1234567890" class="btn btn-secondary">Call Emergency Line</a>
              </div>

              <!-- Service Guarantee -->
              <div class="service-guarantee">
                <h4>Our Guarantee</h4>
                <ul>
                  <li>✓ Free, no-obligation estimates</li>
                  <li>✓ Licensed and insured</li>
                  <li>✓ 100% satisfaction guarantee</li>
                  <li>✓ Same-day response</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- FAQ Section -->
      <section class="faq-section" aria-labelledby="faq-heading">
        <div class="container">
          <h2 id="faq-heading" class="section-title">Frequently Asked Questions</h2>

          <div class="faq-grid">
            <div class="faq-item" itemscope itemtype="https://schema.org/Question">
              <h3 class="faq-question" itemprop="name">How quickly can you provide an estimate?</h3>
              <div class="faq-answer" itemprop="acceptedAnswer" itemscope itemtype="https://schema.org/Answer">
                <p itemprop="text">We typically respond to estimate requests within 24 hours and can often provide same-day service quotes. For urgent needs, call us directly for immediate assistance.</p>
              </div>
            </div>

            <div class="faq-item" itemscope itemtype="https://schema.org/Question">
              <h3 class="faq-question" itemprop="name">Do you provide services year-round?</h3>
              <div class="faq-answer" itemprop="acceptedAnswer" itemscope itemtype="https://schema.org/Answer">
                <p itemprop="text">Yes! We offer seasonal services including spring cleanup, summer maintenance, fall leaf removal, and winter tree trimming. Our services adapt to your lawn's needs throughout the year.</p>
              </div>
            </div>

            <div class="faq-item" itemscope itemtype="https://schema.org/Question">
              <h3 class="faq-question" itemprop="name">Are you licensed and insured?</h3>
              <div class="faq-answer" itemprop="acceptedAnswer" itemscope itemtype="https://schema.org/Answer">
                <p itemprop="text">Absolutely. Southern Buck Lawn is fully licensed, bonded, and insured. We carry comprehensive liability insurance to protect both our team and your property during service.</p>
              </div>
            </div>

            <div class="faq-item" itemscope itemtype="https://schema.org/Question">
              <h3 class="faq-question" itemprop="name">What payment methods do you accept?</h3>
              <div class="faq-answer" itemprop="acceptedAnswer" itemscope itemtype="https://schema.org/Answer">
                <p itemprop="text">We accept cash, check, and all major credit cards. For regular maintenance services, we also offer convenient automatic billing options.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- Enhanced Form Validation and UX JavaScript -->
      <script>
        // Form validation and enhancement
        document.addEventListener('DOMContentLoaded', function() {
          const form = document.getElementById('estimateForm');
          const submitBtn = document.getElementById('submitBtn');
          const btnText = submitBtn.querySelector('.btn-text');
          const btnLoading = submitBtn.querySelector('.btn-loading');

          // Real-time validation
          const inputs = form.querySelectorAll('input[required], select[required]');
          inputs.forEach(input => {
            input.addEventListener('blur', validateInput);
            input.addEventListener('input', clearErrors);
          });

          // Service checkboxes validation
          const serviceCheckboxes = form.querySelectorAll('input[name="services[]"]');
          serviceCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', validateServices);
          });

          // Phone number formatting
          const phoneInput = document.getElementById('phone');
          phoneInput.addEventListener('input', formatPhoneNumber);

          // Form submission
          form.addEventListener('submit', handleFormSubmit);

          function validateInput(e) {
            const input = e.target;
            const errorElement = document.getElementById(input.id + '-error');

            if (!input.value.trim()) {
              showError(input, errorElement, 'This field is required');
              return false;
            }

            if (input.type === 'email' && !isValidEmail(input.value)) {
              showError(input, errorElement, 'Please enter a valid email address');
              return false;
            }

            if (input.type === 'tel' && !isValidPhone(input.value)) {
              showError(input, errorElement, 'Please enter a valid phone number');
              return false;
            }

            clearError(input, errorElement);
            return true;
          }

          function validateServices() {
            const checkedServices = form.querySelectorAll('input[name="services[]"]:checked');
            const errorElement = document.getElementById('services-error');

            if (checkedServices.length === 0) {
              errorElement.textContent = 'Please select at least one service';
              return false;
            }

            errorElement.textContent = '';
            return true;
          }

          function clearErrors(e) {
            const input = e.target;
            const errorElement = document.getElementById(input.id + '-error');
            if (errorElement) {
              clearError(input, errorElement);
            }
          }

          function showError(input, errorElement, message) {
            input.classList.add('error');
            errorElement.textContent = message;
            errorElement.setAttribute('aria-hidden', 'false');
          }

          function clearError(input, errorElement) {
            input.classList.remove('error');
            errorElement.textContent = '';
            errorElement.setAttribute('aria-hidden', 'true');
          }

          function formatPhoneNumber(e) {
            const input = e.target;
            const value = input.value.replace(/\D/g, '');
            const formattedValue = value.replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3');
            input.value = formattedValue;
          }

          function isValidEmail(email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
          }

          function isValidPhone(phone) {
            const phoneRegex = /^\(\d{3}\) \d{3}-\d{4}$/;
            return phoneRegex.test(phone);
          }

          async function handleFormSubmit(e) {
            e.preventDefault();

            // Validate all required fields
            let isValid = true;
            inputs.forEach(input => {
              if (!validateInput({ target: input })) {
                isValid = false;
              }
            });

            if (!validateServices()) {
              isValid = false;
            }

            if (!isValid) {
              // Focus on first error
              const firstError = form.querySelector('.error');
              if (firstError) {
                firstError.focus();
              }
              return;
            }

            // Show loading state
            submitBtn.disabled = true;
            btnText.style.display = 'none';
            btnLoading.style.display = 'inline';

            try {
              // Simulate form submission (replace with actual endpoint)
              const formData = new FormData(form);
              const response = await fetch('/submit-estimate', {
                method: 'POST',
                body: formData
              });

              if (response.ok) {
                // Success - show thank you message
                form.innerHTML = \`
                  <div class="form-success">
                    <h3>Thank You!</h3>
                    <p>Your estimate request has been submitted successfully. We'll contact you within 24 hours to discuss your lawn care needs.</p>
                    <p>For immediate assistance, call us at <a href="tel:+1234567890">(123) 456-7890</a></p>
                  </div>
                \`;
              } else {
                throw new Error('Submission failed');
              }
            } catch (error) {
              // Error handling
              alert('There was an error submitting your request. Please try again or call us directly at (123) 456-7890');

              // Reset button state
              submitBtn.disabled = false;
              btnText.style.display = 'inline';
              btnLoading.style.display = 'none';
            }
          }
        });
      </script>
    `,
    'Contact Southern Buck Lawn for your free lawn care estimate. Serving Plano, Frisco, Allen, and McKinney, TX with professional landscaping services.'
  )
}