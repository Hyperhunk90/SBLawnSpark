import { html } from 'hono/html'
import { layout } from '../../components/layout'
import { localBusinessSchema } from '../../utils/schema'

export function planoPage() {
  const locationSchema = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": "Southern Buck Lawn - Plano",
    "description": "Professional lawn care and landscaping services in Plano, TX. Expert lawn mowing, tree trimming, and landscape design.",
    "address": {
      "@type": "PostalAddress",
      "addressLocality": "Plano",
      "addressRegion": "TX",
      "postalCode": "75023",
      "addressCountry": "US"
    },
    "telephone": "+1234567890",
    "email": "info@southernbucklawn.com",
    "url": "https://southernbucklawn.com/plano",
    "serviceArea": {
      "@type": "GeoCircle",
      "geoMidpoint": {
        "@type": "GeoCoordinates",
        "addressLocality": "Plano",
        "addressRegion": "TX"
      },
      "geoRadius": "15 miles"
    },
    "hasOfferCatalog": {
      "@type": "OfferCatalog",
      "name": "Lawn Care Services in Plano",
      "itemListElement": [
        {
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service",
            "name": "Lawn Mowing in Plano",
            "description": "Professional weekly lawn mowing service"
          }
        },
        {
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service",
            "name": "Tree Trimming in Plano",
            "description": "Expert tree pruning and trimming"
          }
        },
        {
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service",
            "name": "Landscaping in Plano",
            "description": "Complete landscape design and maintenance"
          }
        }
      ]
    }
  }

  return layout(
    'Lawn Care Plano, TX - Professional Landscaping Services | Southern Buck Lawn',
    html`
      <script type="application/ld+json">
        ${JSON.stringify(locationSchema)}
      </script>
      <script type="application/ld+json">
        ${JSON.stringify(localBusinessSchema)}
      </script>

      <!-- Location Hero Section -->
      <section class="hero-section location-hero" role="banner">
        <div class="hero-content">
          <h1 class="hero-title">Professional Lawn Care in Plano, TX</h1>
          <p class="hero-subtitle">Trusted local landscaping services for Plano residents and businesses</p>
          <div class="hero-cta">
            <a href="/contact" class="btn btn-primary">Get Free Estimate</a>
            <a href="tel:+1234567890" class="btn btn-secondary">Call (123) 456-7890</a>
          </div>
        </div>
        <img 
          src="/static/images/locations/plano-hero.jpg" 
          alt="Professional lawn care services in Plano, Texas" 
          class="hero-bg"
          width="1920" 
          height="1080"
          loading="eager"
          fetchpriority="high"
        >
      </section>

      <!-- Location Services Overview -->
      <section class="location-services" aria-labelledby="services-heading">
        <div class="container">
          <h2 id="services-heading" class="section-title">Lawn Care Services in Plano</h2>
          <p class="section-subtitle">
            Serving West Plano, East Plano, Legacy West, Willow Bend, Preston Meadow and surrounding Plano neighborhoods with professional landscaping solutions
          </p>

          <div class="services-grid">
            <div class="service-card">
              <div class="service-icon">🌱</div>
              <h3 class="service-title">Lawn Mowing & Maintenance</h3>
              <p class="service-description">
                Weekly lawn mowing service throughout Plano. We maintain consistent cutting heights 
                and provide edge trimming for a professional appearance.
              </p>
              <ul class="service-features">
                <li>Weekly/bi-weekly scheduling</li>
                <li>Precision cutting equipment</li>
                <li>Edge trimming included</li>
                <li>Debris cleanup</li>
              </ul>
            </div>

            <div class="service-card">
              <div class="service-icon">🌳</div>
              <h3 class="service-title">Tree Trimming & Pruning</h3>
              <p class="service-description">
                Expert tree trimming services for Plano properties. Our certified arborists 
                ensure healthy tree growth while maintaining safety and aesthetics.
              </p>
              <ul class="service-features">
                <li>Certified arborist techniques</li>
                <li>Safety-focused approach</li>
                <li>Health assessment included</li>
                <li>Complete cleanup service</li>
              </ul>
            </div>

            <div class="service-card">
              <div class="service-icon">🌿</div>
              <h3 class="service-title">Landscape Design & Installation</h3>
              <p class="service-description">
                Transform your Plano property with custom landscape design. From concept 
                to installation, we create beautiful outdoor spaces that thrive in North Texas.
              </p>
              <ul class="service-features">
                <li>Custom design consultation</li>
                <li>Native plant selection</li>
                <li>Hardscape integration</li>
                <li>Irrigation planning</li>
              </ul>
            </div>

            <div class="service-card">
              <div class="service-icon">🍂</div>
              <h3 class="service-title">Seasonal Cleanup Services</h3>
              <p class="service-description">
                Year-round maintenance for Plano properties including leaf removal, 
                mulching, and seasonal garden preparation.
              </p>
              <ul class="service-features">
                <li>Fall leaf removal</li>
                <li>Spring cleanup</li>
                <li>Mulch installation</li>
                <li>Garden bed maintenance</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <!-- Local Area Information -->
      <section class="local-area-info">
        <div class="container">
          <h2 class="section-title">Why Choose Southern Buck Lawn in Plano?</h2>

          <div class="local-benefits-grid">
            <div class="benefit-item">
              <h3>Local Plano Expertise</h3>
              <p>
                We understand Plano's unique climate, soil conditions, and native vegetation. 
                Our team has extensive experience working in Plano neighborhoods and knows 
                what works best for North Texas lawns.
              </p>
            </div>

            <div class="benefit-item">
              <h3>Fast Response Times</h3>
              <p>
                Located in the heart of North Texas, we provide quick response times for all 
                Plano service calls. Most estimates are provided within 24 hours.
              </p>
            </div>

            <div class="benefit-item">
              <h3>Licensed & Insured</h3>
              <p>
                Fully licensed to operate in Plano and surrounding areas. We carry 
                comprehensive insurance to protect your property and our team.
              </p>
            </div>

            <div class="benefit-item">
              <h3>Competitive Pricing</h3>
              <p>
                Fair, transparent pricing for all Plano residents. We provide detailed 
                estimates with no hidden fees or surprise charges.
              </p>
            </div>
          </div>
        </div>
      </section>

      <!-- Neighborhoods Served -->
      <section class="neighborhoods-served">
        <div class="container">
          <h2 class="section-title">Plano Neighborhoods We Serve</h2>
          <div class="neighborhoods-grid">
            <div class="neighborhood-item"><h4>West Plano</h4></div> <div class="neighborhood-item"><h4>East Plano</h4></div> <div class="neighborhood-item"><h4>Legacy West</h4></div> <div class="neighborhood-item"><h4>Willow Bend</h4></div> <div class="neighborhood-item"><h4>Preston Meadow</h4></div>
          </div>
          <p class="neighborhoods-note">
            Don't see your neighborhood listed? We serve all of Plano and surrounding areas. 
            <a href="/contact">Contact us</a> to confirm service in your area.
          </p>
        </div>
      </section>

      <!-- Local Testimonials -->
      <section class="local-testimonials">
        <div class="container">
          <h2 class="section-title">What Plano Customers Say</h2>

          <div class="testimonials-grid">
            <blockquote class="testimonial-card" itemscope itemtype="https://schema.org/Review">
              <div class="testimonial-content">
                <p class="testimonial-text" itemprop="reviewBody">
                  "Southern Buck has been taking care of our Plano property for over two years. 
                  They're reliable, professional, and our lawn has never looked better!"
                </p>
                <div class="testimonial-author">
                  <span class="author-name" itemprop="author">- Jennifer K.</span>
                  <span class="author-location">Plano, TX</span>
                </div>
                <div class="testimonial-rating" itemprop="reviewRating" itemscope itemtype="https://schema.org/Rating">
                  <meta itemprop="ratingValue" content="5">
                  <meta itemprop="bestRating" content="5">
                  ⭐⭐⭐⭐⭐
                </div>
              </div>
            </blockquote>

            <blockquote class="testimonial-card" itemscope itemtype="https://schema.org/Review">
              <div class="testimonial-content">
                <p class="testimonial-text" itemprop="reviewBody">
                  "Excellent tree trimming service! They cleaned up everything and left our Plano 
                  yard looking fantastic. Highly recommend!"
                </p>
                <div class="testimonial-author">
                  <span class="author-name" itemprop="author">- Michael R.</span>
                  <span class="author-location">Plano, TX</span>
                </div>
                <div class="testimonial-rating" itemprop="reviewRating" itemscope itemtype="https://schema.org/Rating">
                  <meta itemprop="ratingValue" content="5">
                  <meta itemprop="bestRating" content="5">
                  ⭐⭐⭐⭐⭐
                </div>
              </div>
            </blockquote>
          </div>
        </div>
      </section>

      <!-- Local CTA -->
      <section class="local-cta-section">
        <div class="container">
          <h2 class="cta-title">Ready to Transform Your Plano Property?</h2>
          <p class="cta-subtitle">
            Join hundreds of satisfied Plano customers who trust Southern Buck Lawn 
            for their landscaping needs
          </p>
          <div class="cta-buttons">
            <a href="/contact" class="btn btn-primary">Get Your Free Estimate</a>
            <a href="tel:+1234567890" class="btn btn-secondary">Call (123) 456-7890</a>
          </div>
        </div>
      </section>
    `,
    'Professional lawn care and landscaping services in Plano, TX. Expert lawn mowing, tree trimming, and landscape design for Plano residents and businesses.'
  )
}